package interfaz;

import mundo.AdministracionMcDonalds;

public class Main {

    public static void main(String[] args) {
        // Crear una instancia de AdministracionMcDonalds
        AdministracionMcDonalds admin = new AdministracionMcDonalds();
        
        // Crear una instancia de McDonaldsCLI y pasarle el objeto admin
        McDonaldsCLI mcDonaldsCLI = new McDonaldsCLI(admin);
        
        try {
            // Ejecutar el menú principal de McDonaldsCLI
            mcDonaldsCLI.mainMenu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
