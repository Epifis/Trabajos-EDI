package estructuras;
//Paso 1, crear la clase ListaDobleEncadenada

import java.util.Iterator;


/**
 * 
 * @author AlexandraTinjaca
 * @param <E> 
 * 
 * Lista doblemente encadenada genérica, no olvide tener cuenta los
 * siguientes métodos: size(), isEmpty(), addFirst(E element), addLast(E element), 
 * removeFirst(E element), removeLast(E element), first() y last().
 */
public class ListaDobleEncadenada<E> {

    private NodoLista<E> cabeza;
    private NodoLista<E> cola;
    private int size;

    // Constructor
    public ListaDobleEncadenada() {
        cabeza = null;
        cola = null;
        size = 0;
    }

    // Obtener el primer nodo
    public NodoLista<E> first() {
        return cabeza;
    }

    // Obtener el último nodo
    public NodoLista<E> last() {
        return cola;
    }

    // Agregar un elemento al principio de la lista
    public void addFirst(E element) {
        NodoLista<E> nuevoNodo = new NodoLista<>(element, cabeza, null);
        if (cabeza != null) {
            cabeza.setPrev(nuevoNodo);
        }
        cabeza = nuevoNodo;
        if (cola == null) {
            cola = nuevoNodo;
        }
        size++;
    }

    // Agregar un elemento al final de la lista
    public void addLast(E element) {
        NodoLista<E> nuevoNodo = new NodoLista<>(element, null, cola);
        if (cola != null) {
            cola.setSiguiente(nuevoNodo);
        }
        cola = nuevoNodo;
        if (cabeza == null) {
            cabeza = nuevoNodo;
        }
        size++;
    }

    // Eliminar el primer elemento de la lista
    public void removeFirst() {
        if (isEmpty()) {
            System.out.println("Lista vacia");
        }
        cabeza = cabeza.getSiguiente();
        if (cabeza != null) {
            cabeza.setPrev(null);
        } else {
            cola = null;
        }
        size--;
    }

    // Eliminar el último elemento de la lista
    public void removeLast() {
        if (isEmpty()) {
            System.out.println("Lista vacia");
        }
        cola = cola.getPrev();
        if (cola != null) {
            cola.setSiguiente(null);
        } else {
            cabeza = null;
        }
        size--;
    }

    // Eliminar un nodo específico
    public void remove(NodoLista<E> nodo) {
        if (nodo == null) {
            throw new IllegalArgumentException("Nodo no puede ser nulo");
        }
        if (nodo == cabeza) {
            removeFirst();
        } else if (nodo == cola) {
            removeLast();
        } else {
            NodoLista<E> prev = nodo.getPrev();
            NodoLista<E> next = nodo.getSiguiente();
            if (prev != null) {
                prev.setSiguiente(next);
            }
            if (next != null) {
                next.setPrev(prev);
            }
            size--;
        }
    }

    // Obtener el tamaño de la lista
    public int size() {
        return size;
    }

    // Verificar si la lista está vacía
    public boolean isEmpty() {
        return size == 0;
    }

    public Iterator<Producto> iterator() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
