package estructuras;
//Paso 2, crear la clase NodoLista
/**
 * 
 * @author AlexandraTinjaca
 * @param <E> 
 * 
 * Clase que representará uno de los nodos de la lista definida anteriormente. Para
 * esta clase no olvide los métodos: getElement(), setElement(E element), getNext(),
 * setNext(NodoLista<E> next), getPrev() y setPrev(NodoLista<E> prev).

 */
public class NodoLista<E> {
    private E elemento;
    private NodoLista<E> siguiente;
    private NodoLista<E> prev;

    public NodoLista(E elemento, NodoLista<E> siguiente, NodoLista<E> prev) {
        this.elemento = elemento;
        this.siguiente = siguiente;
        this.prev = prev;
    }

    public E getElemento() {
        return elemento;
    }

    public void setElemento(E elemento) {
        this.elemento = elemento;
    }

    public NodoLista<E> getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoLista<E> siguiente) {
        this.siguiente = siguiente;
    }

    public NodoLista<E> getPrev() {
        return prev;
    }

    public void setPrev(NodoLista<E> prev) {
        this.prev = prev;
    }
}
