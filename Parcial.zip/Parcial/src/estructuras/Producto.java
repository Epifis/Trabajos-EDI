package estructuras;
//Paso 3. Crear clase Producto
/**
 * 
 * @author Alexandra Tinjaca
 * 
 * Un producto es el elemento en sí que se vende. Un producto puede tener los
 * siguientes atributos: nombre, tiempoPreparacion y costo (como los que tiene Pedido ahora en el enum)
 */
public class Producto {
    private String nombre;
    private long tiempoPreparacion;
    private double costo;

    public Producto(String nombre, long tiempoPreparacion, double costo) {
        this.nombre = nombre;
        this.tiempoPreparacion = tiempoPreparacion;
        this.costo = costo;
    }

    public String getNombre() {
        return nombre;
    }

    public long getTiempoPreparacion() {
        return tiempoPreparacion;
    }

    public double getCosto() {
        return costo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTiempoPreparacion(long tiempoPreparacion) {
        this.tiempoPreparacion = tiempoPreparacion;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
}
