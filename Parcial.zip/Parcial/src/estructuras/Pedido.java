package estructuras;
//paso 4. Crear clase pedido
/**
 *
 * @author Alexandra Tinjaca
 * 
 * Un pedido es una solicitud para la entrega de un producto a un cliente. Un pedido
 * debe contar con los siguientes atributos: horaPedido, producto y direccion (si es un domicilio,
 * por lo que puede también manejar el estado esDomicilio si lo desea).
 * 
 */

public class Pedido {
    private String horaPedido;
    private Producto producto;
    private String direccion;
    private boolean esDomicilio;

    public Pedido(String horaPedido, Producto producto, String direccion, boolean esDomicilio) {
        this.horaPedido = horaPedido;
        this.producto = producto;
        this.direccion = direccion;
        this.esDomicilio = esDomicilio;
    }

    public String getHoraPedido() {
        return horaPedido;
    }

    public Producto getProducto() {
        return producto;
    }

    public String getDireccion() {
        return direccion;
    }

    public boolean esDomicilio() {
        return esDomicilio;
    }

    public void setHoraPedido(String horaPedido) {
        this.horaPedido = horaPedido;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setEsDomicilio(boolean esDomicilio) {
        this.esDomicilio = esDomicilio;
    }
}
