package mundo;

import estructuras.Pedido;
import estructuras.Producto;
import estructuras.Cola;
import estructuras.ListaDobleEncadenada;
import estructuras.NodoLista;

public class AdministracionMcDonalds {

    private ListaDobleEncadenada<Producto> catalogoProductos;
    private Cola<Pedido> colaPedidos;
    private Cola<Pedido> colaDomicilios;
    private Cola<String> colaClientes;

    // Constructor
    public AdministracionMcDonalds() {
        // Inicializa las colas y el catálogo de productos
        colaPedidos = new Cola<>();
        colaDomicilios = new Cola<>();
        catalogoProductos = new ListaDobleEncadenada<>();
        
        // Agrega productos iniciales al catálogo
        catalogoProductos.addLast(new Producto("Combo Nuggets", 200, 5.99));
        catalogoProductos.addLast(new Producto("Combo Big Mac", 300, 6.99));
        catalogoProductos.addLast(new Producto("Combo Cuarto de Libra", 250, 7.49));
        catalogoProductos.addLast(new Producto("McFlurry", 100, 3.49));
    }

    public void agregarCliente(String nombre){
		colaClientes.encolar(nombre);
	}
    // Métodos de acceso para la cola de pedidos
    public Cola<Pedido> getColaPedidos() {
        return colaPedidos;
    }

    // Método para agregar un pedido a la cola de pedidos
    public void agregarPedido(Pedido pedido) {
        colaPedidos.encolar(pedido);
    }

    // Método para entregar un pedido
    public String entregarPedido() {
        Pedido p = colaPedidos.desencolar();
        try {
            Thread.sleep(p.getProducto().getTiempoPreparacion());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return p.getProducto().getNombre();
    }

    // Métodos para manejar el catálogo de productos
    public ListaDobleEncadenada<Producto> getCatalogoProductos() {
        return catalogoProductos;
    }

    // Agregar un producto al catálogo
    public void agregarProducto(Producto producto) {
        catalogoProductos.addLast(producto);
    }

    // Eliminar un producto del catálogo
    public void eliminarProducto(Producto producto) {
        NodoLista<Producto> nodo = catalogoProductos.first();
        while (nodo != null) {
            if (nodo.getElemento().equals(producto)) {
                catalogoProductos.remove(nodo);
                break;
            }
            nodo = nodo.getSiguiente();
        }
    }

    // Manejo de la cola de domicilios
    public Cola<Pedido> getColaDomicilios() {
        return colaDomicilios;
    }

    // Agregar un domicilio a la cola de domicilios
    public void agregarDomicilio(Pedido pedido) {
        colaDomicilios.encolar(pedido);
    }

    // Entregar un domicilio
    public String entregarDomicilio() {
        Pedido p = colaDomicilios.desencolar();
        try {
            Thread.sleep(p.getProducto().getTiempoPreparacion());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return p.getProducto().getNombre();
    }

    // Contar clientes en la cola de pedidos
    public Cola clientesEnFila() {
        return colaPedidos;
    }

    // Contar pedidos en espera
    public int pedidosEnEspera() {
        return colaPedidos.tamanio();
    }
}

/*
public class AdministracionMcDonalds{
	
	private Cola<String> colaClientes;
	private Cola<Pedido> colaPedidos;
	public enum Pedido{
		NUGGETS ("Combo Nuggets",200),
		BIGMAC ("Combo Bigmac", 300),
		CUARTO ("Combo Cuarto de Libra", 250),
		MCFLURRY ("McFlurry", 100);
	
		private final String nombre;
		private final long tiempoProceso;
		private Pedido(String nombre, long tiempoProceso) {
			this.nombre = nombre;
			this.tiempoProceso = tiempoProceso;
		}
		public String getNombre() {
			return nombre;
		}
		public long getTiempoProceso() {
			return tiempoProceso;
		}	
	}
	
	public AdministracionMcDonalds(){
		colaClientes=new Cola<String>();
		colaPedidos=new Cola<Pedido>();
	}
	
	public void agregarCliente(String nombre){
		colaClientes.encolar(nombre);
	}
	
	public String atenderCliente(Pedido pedido){
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {

		}
		colaPedidos.encolar(pedido);
		return colaClientes.desencolar();
	}
	
	public String entregarPedido(){
		Pedido p = colaPedidos.desencolar();
		try {
			Thread.sleep(p.getTiempoProceso());
		} catch (InterruptedException e) {

		}
		return p.getNombre();
	}
	
	public int clientesEnFila(){
		return colaClientes.tamanio();
	}
	
	public int pedidosEnEspera(){
		return colaPedidos.tamanio();
	}
	
	public Iterator<String> clientes(){
		return colaClientes.iterator();
	}
	
	public Iterator<Pedido> pedidos(){
		return colaPedidos.iterator();
	}
 */
