package claseestructuradedatos;

public class ClaseEstructuraDeDatos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bag bolsa;
        bolsa = new Bag();
        bolsa.add(args);
        System.out.println(bolsa.size());
    }

}
/**
 * Notas Arreglos fijos o variables Listas dinámicas o encadenadas
 *
 *Auto-boxing: Para hacer generización se hace con clases, no se puede hacer con tipos primitivos (Integer) sino con int
 * Stack<Integer> stack = new Stack<Integer> ();
 * stack.push;
 * 
 * Colecciones iterables (for e, etc)
 * 
 * 
 * API
 * - Cada Collection tiene un constructor sin args, metodos para añadir, comprobar si está vacía, etc
 * 
 * 
 * Bolsa: public class Bag<Item> implements Iterable<Item>
 * 
 * Bag() crea una bolsa
 * void add(Item item)
 * bolean isEmpty()
 * int size()
 * 
 * Colección donde no se pueden eliminar elemntos, el orden de iteración no es especifico, puede añadir elementos y procesarlos
 * 
 */
