
package claseestructuradedatos;

import java.util.Iterator;

public class Bag<Item> implements Iterable<Item> {
    private Item [] items;

    public static final int max = 25;
    
    public Bag() {
        this.items =(Item[]) new Object[max];
    }
    public void add(Item item){
        
    }
    public boolean isEmpty(){
        return true;
    }
    public int size(){
    
        return 1;
    }

    @Override
    public Iterator<Item> iterator() {
        return new ArregloIter<>(items);
    }

    private class ArregloIter<Item> implements Iterator <Item> {
        private Item[] lista;
        public int recorrido;
        public ArregloIter(Item[] items) {
            lista = items;
            recorrido = 0;
        }

        @Override
        public boolean hasNext() {
            return false;
        }

        @Override
        public Item next() {
            return lista[4];
        }

    }
}
