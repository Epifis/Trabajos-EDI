public interface ComparableDate {
    public int compareTo (Estudiante estudiante);
    
}
