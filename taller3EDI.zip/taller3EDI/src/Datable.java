public interface Datable {
    
    public String nombre();
    public int edad();
    public String carrera();
    public int semestre();
    public int creditos();
    
}
